        
        
    <div class="container-fluid">
        <div class="row"> 
            <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
                <footer class="main-footer d-flex p-2 px-3 bg-white border-top">            
                    <span class="copyright mr-auto my-auto mr-2">
                        Copyright   <script>document.write(new Date().getFullYear())</script>&copy; Real Estate               
                    </span>
                </footer>
            </main>
        </div>
    </div>